
  const form = document.getElementById("contactForm");
  const container = document.getElementById("formContainer");
  const thankYou = document.getElementById("thankYouMessage");

  form.addEventListener("submit", function(e) {
    e.preventDefault(); 

    container.style.display = "none";   
    thankYou.style.display = "block";   
  });

function toggleMenu() {
  const menu = document.getElementById("menu");
  menu.style.display = menu.style.display === "block" ? "none" : "block";
  const hamburger = document.querySelector(".hamburger");
if(menu.style.display === "block"){
  hamburger.style.display = "none";}

}
